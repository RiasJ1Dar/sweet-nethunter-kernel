#!/system/bin/sh
# Вантажимо драйвери після монтування overlay; раніше /vendor/lib/modules ще не видно.
sleep 45
for m in ath ath9k_hw ath9k_common ath9k_htc eeprom_93cx6 carl9170 \
         rt2x00lib rt2x00usb rt2800lib rt2800usb \
         rtlwifi rtl_usb rtl8192c-common rtl8192cu rtl8187; do
    insmod /vendor/lib/modules/$m.ko 2>/dev/null
done
